package com.example.ktra1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ktra1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
