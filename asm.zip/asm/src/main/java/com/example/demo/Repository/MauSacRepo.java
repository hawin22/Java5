package com.example.demo.Repository;

import com.example.demo.model.MauSac;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MauSacRepo extends JpaRepository<MauSac, Integer> {
}
