package com.example.demo.model;

import java.util.Date;

public interface DanhMucView {
    Integer getId();
    String getMa_danh_muc();
    String geTen_danh_muc();
    String getTrang_thai();
    Date getNgay_tao();
    Date getNgay_sua();
}
