package com.example.demo.model;

public interface HoaDonChiTietViewSS {
    Integer getId();
    Integer getId_ctsp();
}
