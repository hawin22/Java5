package com.example.demo.model;


import java.util.Date;

public interface KhachHangView {
      Integer getId();
     String getHo_ten();
     String getDia_chi();
     String getSdt();
     String getTrang_thai();
     Date getNgay_tao();
     Date getNgay_sua();

}
