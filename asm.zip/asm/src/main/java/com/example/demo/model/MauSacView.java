package com.example.demo.model;

import java.util.Date;

public interface MauSacView {
    Integer getId();
    String getMa_mau();
    String getTen_mau();
    String getTrang_thai();
    Date getNgay_sua();
    Date getNgay_tao();
}
