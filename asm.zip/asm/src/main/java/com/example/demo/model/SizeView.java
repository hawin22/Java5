package com.example.demo.model;

import java.util.Date;

public interface SizeView {
    Integer getId();
    String getMa_size();
    String getTen_size();
    String getTrang_thai();
    Date getNgay_sua();
    Date getNgay_tao();
}
